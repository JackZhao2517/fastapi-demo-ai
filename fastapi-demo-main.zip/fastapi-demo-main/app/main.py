from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
import os
from app.db.database import engine
from app.db import models
from app.routers import user

app = FastAPI(title="FastAPI on Cloud Run")

# 允许跨域
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

@app.on_event("startup")
async def startup_event():
    """应用启动时创建数据库表"""
    try:
        models.Base.metadata.create_all(bind=engine)
        print("Database tables created successfully")
    except Exception as e:
        print(f"Error creating database tables: {e}")

# 注册路由
app.include_router(user.router)

@app.get("/")
def root():
    return {"message": "API Successfully Deployed on Cloud Run!"}

@app.get("/health")
def health_check():
    return {"status": "healthy", "message": "Service is running"}

@app.get("/test")
def test_endpoint():
    return {"message": "Test endpoint working", "environment": "Cloud Run"}