import os
from dotenv import load_dotenv

load_dotenv()

class Settings:
    POSTGRES_URL: str = os.getenv(
        "POSTGRES_URL",
        "postgresql://dbadmin:dbadmin@130.211.95.208:5432/fastapi_demo"
    )

settings = Settings()
